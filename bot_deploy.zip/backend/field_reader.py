import google.generativeai as genai
import json
import os
import io
import requests
from typing import Dict, Optional, Union
from backend.prompts import (
    COLD_SYSTEM_PROMPT, 
    RED_FLAG_SYSTEM_PROMPT,
    DREAM_SYSTEM_PROMPT,
    MED_SYSTEM_PROMPT,
    DREAM_SYSTEM_PROMPT,
    MED_SYSTEM_PROMPT,
    PAPER_SYSTEM_PROMPT,
    RED_FLAG_PREMIUM_PROMPT,
    DREAM_PREMIUM_PROMPT,
    MED_PREMIUM_PROMPT,
    PAPER_PREMIUM_PROMPT,
    REELS_SYSTEM_PROMPT
)

class FieldReader:
    def __init__(self, api_key: str = None):
        # Fallback to key in env or default
        self.api_key = api_key or os.getenv("GEMINI_API_KEY") or "AIzaSyAVcKK5KcpduBv2hh-uvMreDGvTHX-uURE" 
        genai.configure(api_key=self.api_key)
        self.model = genai.GenerativeModel('gemini-2.0-flash-exp') # FIXED: Bleeding Edge (User calls it Gemini 3)

    def _get_prompt(self, mode: str) -> str:
        # FACTORY MODES
        if mode == "reels": return REELS_SYSTEM_PROMPT
        
        # PREMIUM MODES
        if mode == "red_flag_premium": return RED_FLAG_PREMIUM_PROMPT
        if mode == "dream_premium": return DREAM_PREMIUM_PROMPT
        if mode == "med_premium": return MED_PREMIUM_PROMPT
        if mode == "paper_premium": return PAPER_PREMIUM_PROMPT

        # STANDARD MODES
        if mode == "red_flag": return RED_FLAG_SYSTEM_PROMPT
        if mode == "dream": return DREAM_SYSTEM_PROMPT
        if mode == "med": return MED_SYSTEM_PROMPT
        if mode == "paper": return PAPER_SYSTEM_PROMPT
        if mode == "contract": return COLD_SYSTEM_PROMPT
        
        return COLD_SYSTEM_PROMPT # Default

    def download_file(self, file_id: str, bot_token: str) -> bytes:
        """
        Downloads a file from Telegram by file_id.
        """
        # 1. Get File Path
        get_file_url = f"https://api.telegram.org/bot{bot_token}/getFile?file_id={file_id}"
        r = requests.get(get_file_url)
        if r.status_code != 200:
            raise Exception("Failed to get file info from Telegram")
        
        file_path = r.json()['result']['file_path']
        
        # 2. Download Content
        download_url = f"https://api.telegram.org/file/bot{bot_token}/{file_path}"
        file_content = requests.get(download_url).content
        return file_content

    async def analyze_content(self, text: str = "", media_content: bytes = None, mime_type: str = None, mode: str = "red_flag") -> dict:
        """
        Analyzes text OR media (image/pdf) using Gemini 1.5 Flash.
        """
        system_prompt = self._get_prompt(mode)
        
        content_parts = [system_prompt]
        
        if text:
            content_parts.append(f"ВХОДНОЙ ТЕКСТ:\n{text}")
            
        if media_content and mime_type:
            content_parts.append("ПРОАНАЛИЗИРУЙ ЭТОТ ФАЙЛ (Скриншот или Документ):")
            # Create a Part object
            cookie_picture = {
                'mime_type': mime_type,
                'data': media_content
            }
            content_parts.append(cookie_picture)
        
        try:
            # Generate content
            response = self.model.generate_content(content_parts)
            
            # Simple Text Response (since prompts ask for formatted text, not always JSON)
            # If we need structured JSON, we should enforce it in prompts, but user wants Design/Text.
            # The prompts currently ask for a structured markdown report.
            return {"raw_text": response.text}
            
        except Exception as e:
            return {
                "error": str(e),
                "raw_text": f"⚠️ **Ошибка анализа:** {str(e)}. Попробуйте отправить текст."
            }

if __name__ == "__main__":
    reader = FieldReader()
    print("FieldReader Initialized.")
